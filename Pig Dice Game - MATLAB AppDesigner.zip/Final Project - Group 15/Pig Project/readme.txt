Run main.mlapp.
Youtube Link: https://youtu.be/rpC-BV76OyA

The image files used are in the Images folder and the audio used in the Sounds folder. For remote gameplay, remember to run it on two different devices to see the interaction.

